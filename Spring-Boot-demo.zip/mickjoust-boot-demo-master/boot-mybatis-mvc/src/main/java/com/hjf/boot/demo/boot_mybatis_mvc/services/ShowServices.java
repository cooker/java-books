package com.hjf.boot.demo.boot_mybatis_mvc.services;

import org.springframework.stereotype.Service;

/**
 * Created by mickjoust on 2016/6/8.
 * com.hjf.boot.demo.boot_mybatis_mvc.services
 */
@Service
public class ShowServices {
}
