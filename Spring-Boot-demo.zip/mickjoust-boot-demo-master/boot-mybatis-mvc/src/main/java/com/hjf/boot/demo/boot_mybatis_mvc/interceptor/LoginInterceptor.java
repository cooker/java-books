package com.hjf.boot.demo.boot_mybatis_mvc.interceptor;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * Created by mickjoust on 2016/6/8.
 * com.hjf.boot.demo.boot_mybatis_mvc.interceptor
 */
public class LoginInterceptor extends HandlerInterceptorAdapter {



}
