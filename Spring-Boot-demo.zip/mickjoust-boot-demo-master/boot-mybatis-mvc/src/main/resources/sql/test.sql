CREATE TABLE `info` (
`id`  bigint NOT NULL AUTO_INCREMENT ,
`name`  varchar(255) NULL ,
`age`  int NULL ,
PRIMARY KEY (`id`)
);

INSERT INTO info (name,age) VALUES ('mick','20');
INSERT INTO info (name,age) VALUES ('mick1','20');
INSERT INTO info (name,age) VALUES ('mickjoust1','21');
INSERT INTO info (name,age) VALUES ('joust','22');